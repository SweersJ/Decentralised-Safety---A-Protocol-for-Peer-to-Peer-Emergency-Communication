const { Plugin, FileView } = require("obsidian");

const VIEW_TYPE_QUINT = "quint-file-view";

class QuintFileView extends FileView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this._editMode = false;
    this._actionButton = null;
  }

  getViewType() { return VIEW_TYPE_QUINT; }
  getDisplayText() { return this.file?.basename ?? "Quint"; }
  getIcon() { return "code-2"; }

  onOpen() {
    this._actionButton = this.addAction("pencil", "Edit file", () => this._toggleMode());
  }

  async onLoadFile(file) {
    await super.onLoadFile(file);
    this._editMode = false;
    this._updateActionButton();
    await this._renderPreview(file);
  }

  async onUnloadFile(file) {
    await super.onUnloadFile(file);
    this.contentEl.empty();
  }

  _updateActionButton() {
    if (!this._actionButton) return;
    if (this._editMode) {
      this._actionButton.setAttribute("aria-label", "Preview file");
      this._actionButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
    } else {
      this._actionButton.setAttribute("aria-label", "Edit file");
      this._actionButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-pencil"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>';
    }
  }

  async _toggleMode() {
    if (!this.file) return;
    if (this._editMode) {
      await this._saveFromEditor();
      this._editMode = false;
      this._updateActionButton();
      await this._renderPreview(this.file);
    } else {
      this._editMode = true;
      this._updateActionButton();
      await this._renderEditor(this.file);
    }
  }

  async _saveFromEditor() {
    const textarea = this.contentEl.querySelector("textarea.qnt-editor");
    if (!textarea || !this.file) return;
    const newSource = textarea.value;
    await this.app.vault.modify(this.file, newSource);
    this.plugin._highlightCache.delete(this.file.path);
  }

  async _renderPreview(file) {
    const container = this.contentEl;
    container.empty();
    container.addClass("markdown-rendered");

    let highlighted = this.plugin._highlightCache.get(file.path);
    if (!highlighted) {
      const source = await this.app.vault.read(file);
      highlighted = highlightQuintWithLineNumbers(source);
      this.plugin._highlightCache.set(file.path, highlighted);
    }

    const pre = container.createEl("pre", { cls: "qnt-file-view" });
    const code = pre.createEl("code", { cls: "language-quint" });
    code.innerHTML = highlighted;
  }

  async _renderEditor(file) {
    const container = this.contentEl;
    container.empty();
    container.removeClass("markdown-rendered");
    container.addClass("qnt-editor-container");

    const source = await this.app.vault.read(file);

    const wrap = container.createEl("div", { cls: "qnt-editor-wrap" });
    const gutter = wrap.createEl("div", { cls: "qnt-line-numbers" });
    const textarea = wrap.createEl("textarea", { cls: "qnt-editor" });
    textarea.spellcheck = false;
    textarea.autocomplete = "off";
    textarea.value = source;

    const update = () => {
      const lines = textarea.value.split("\n").length;
      gutter.textContent = Array.from({ length: lines }, (_, i) => i + 1).join("\n");
      textarea.style.height = "0";
      textarea.style.height = textarea.scrollHeight + "px";
    };

    update();

    textarea.addEventListener("input", update);
    textarea.addEventListener("keydown", async (e) => {
      if (e.key === "s" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        await this._saveFromEditor();
      }
      if (e.key === "Tab") {
        e.preventDefault();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        textarea.value = textarea.value.substring(0, start) + "    " + textarea.value.substring(end);
        textarea.selectionStart = textarea.selectionEnd = start + 4;
        update();
      }
    });

    textarea.focus();
  }
}

const KEYWORDS = new Set([
  "module",
  "import",
  "from",
  "export",
  "as",
  "if",
  "then",
  "else",
  "let",
  "in",
  "all",
  "any",
  "nondet",
  "match",
  "and",
  "or",
  "not",
  "implies",
  "iff",
  "leadsTo",
]);

const DECLS = new Set([
  "type",
  "assume",
  "const",
  "var",
  "val",
  "def",
  "pure",
  "action",
  "temporal",
  "run",
]);

const TEMPORAL = new Set([
  "always",
  "eventually",
  "next",
  "enabled",
  "weakFair",
  "strongFair",
  "orKeep",
  "mustChange",
  "guarantees",
]);

const BUILTINS = new Set([
  "eq",
  "neq",
  "exists",
  "forall",
  "in",
  "contains",
  "union",
  "intersect",
  "exclude",
  "subseteq",
  "filter",
  "map",
  "fold",
  "powerset",
  "flatten",
  "allLists",
  "allListsUpTo",
  "getOnlyElement",
  "chooseSome",
  "oneOf",
  "isFinite",
  "size",
  "get",
  "keys",
  "mapBy",
  "setToMap",
  "setOfMaps",
  "set",
  "setBy",
  "put",
  "append",
  "concat",
  "head",
  "tail",
  "length",
  "nth",
  "indices",
  "replaceAt",
  "slice",
  "range",
  "select",
  "foldl",
  "iadd",
  "isub",
  "imul",
  "idiv",
  "imod",
  "ipow",
  "ilt",
  "igt",
  "ilte",
  "igte",
  "iuminus",
  "to",
  "assign",
  "ite",
  "then",
  "expect",
  "reps",
  "fail",
  "assert",
  "actionAll",
  "actionAny",
  "existsConst",
  "forallConst",
  "chooseConst",
  "item",
  "tuples",
  "field",
  "fieldNames",
  "with",
  "variant",
  "matchVariant",
]);

const TYPES = new Set(["int", "bool", "str", "Set", "List", "Map", "Option", "Tup", "Rec"]);
const LITERALS = new Set(["true", "false", "Bool", "Int", "Nat"]);

const OPERATOR_RE = /^(=>|->|==|!=|<=|>=|::|\+|-|\*|\/|%|\^|=|<|>|\||\.|,|:|;|')/;
const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*/;
const HEX_RE = /^-?0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*/;
const INT_RE = /^-?(?:0|[1-9](?:_?[0-9])*)/;

function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function tokenSpan(cls, text) {
  return `<span class="qnt-${cls}">${escapeHtml(text)}</span>`;
}

function classifyIdentifier(identifier, nextChar) {
  if (identifier === "_") {
    return "wildcard";
  }
  if (DECLS.has(identifier)) {
    return "decl";
  }
  if (KEYWORDS.has(identifier)) {
    return "keyword";
  }
  if (TEMPORAL.has(identifier)) {
    return "temporal";
  }
  if (LITERALS.has(identifier)) {
    return "literal";
  }
  if (TYPES.has(identifier)) {
    return "type";
  }
  if (BUILTINS.has(identifier) || identifier === "q::debug" || identifier === "apalache::generate") {
    return "builtin";
  }
  if (/^[A-Z][A-Z0-9_]*$/.test(identifier)) {
    return "const";
  }
  if (/^[A-Z][A-Za-z0-9_]*$/.test(identifier)) {
    return "constructor";
  }
  if (nextChar === "(") {
    return "fn";
  }
  return "ident";
}

function readString(source, start) {
  let i = start + 1;
  while (i < source.length) {
    const ch = source[i];
    if (ch === "\\") {
      i += 2;
      continue;
    }
    if (ch === '"') {
      i += 1;
      break;
    }
    i += 1;
  }
  return i;
}

function readLineComment(source, start) {
  let i = start;
  while (i < source.length && source[i] !== "\n") {
    i += 1;
  }
  return i;
}

function readBlockComment(source, start) {
  let i = start + 2;
  while (i < source.length - 1) {
    if (source[i] === "*" && source[i + 1] === "/") {
      return i + 2;
    }
    i += 1;
  }
  return source.length;
}

function readNamespacedIdentifier(source, start) {
  let i = start;
  let full = "";
  while (i < source.length) {
    const part = source.slice(i).match(IDENT_RE);
    if (!part) {
      break;
    }
    full += part[0];
    i += part[0].length;
    if (source[i] === ":" && source[i + 1] === ":") {
      full += "::";
      i += 2;
      continue;
    }
    break;
  }
  return { text: full, end: i };
}

function highlightQuintWithLineNumbers(source) {
  const highlighted = highlightQuint(source);
  const lines = highlighted.split("\n");
  return lines.map((line) => `<span class="qnt-line">${line}</span>`).join("\n");
}

function highlightQuint(source) {
  let i = 0;
  let out = "";

  if (source.startsWith("#!")) {
    const end = readLineComment(source, 0);
    out += tokenSpan("comment", source.slice(0, end));
    i = end;
  }

  while (i < source.length) {
    const ch = source[i];

    if (ch === "/" && source[i + 1] === "/") {
      const end = readLineComment(source, i);
      out += tokenSpan("comment", source.slice(i, end));
      i = end;
      continue;
    }

    if (ch === "/" && source[i + 1] === "*") {
      const end = readBlockComment(source, i);
      out += tokenSpan("comment", source.slice(i, end));
      i = end;
      continue;
    }

    if (ch === '"') {
      const end = readString(source, i);
      out += tokenSpan("string", source.slice(i, end));
      i = end;
      continue;
    }

    const hex = source.slice(i).match(HEX_RE);
    if (hex) {
      out += tokenSpan("number", hex[0]);
      i += hex[0].length;
      continue;
    }

    const intNum = source.slice(i).match(INT_RE);
    if (intNum) {
      out += tokenSpan("number", intNum[0]);
      i += intNum[0].length;
      continue;
    }

    if (/[A-Za-z_]/.test(ch)) {
      const { text, end } = readNamespacedIdentifier(source, i);
      const nextChar = source[end] || "";
      const cls = classifyIdentifier(text, nextChar);
      out += tokenSpan(cls, text);
      i = end;
      continue;
    }

    const op = source.slice(i).match(OPERATOR_RE);
    if (op) {
      out += tokenSpan("op", op[0]);
      i += op[0].length;
      continue;
    }

    out += escapeHtml(ch);
    i += 1;
  }

  return out;
}

module.exports = class QuintHighlighterPlugin extends Plugin {
  onload() {
    this._highlightCache = new Map();

    this.registerView(VIEW_TYPE_QUINT, (leaf) => new QuintFileView(leaf, this));

    try {
      this.registerExtensions(["qnt"], VIEW_TYPE_QUINT);
    } catch (e) {
      console.info("quint-highlighter: .qnt extension already registered, skipping.");
    }

    // Highlight quint/qnt fenced code blocks inside regular markdown notes (reading mode).
    this.registerMarkdownPostProcessor((el, ctx) => {
      const blocks = el.querySelectorAll("code.language-quint, code.language-qnt");
      blocks.forEach((code) => {
        if (code.dataset.qntHighlighted === "true") return;
        code.innerHTML = highlightQuint(code.textContent || "");
        code.dataset.qntHighlighted = "true";
      });
    });

    // Highlight quint/qnt fenced code blocks in live preview mode.
    const renderCodeBlock = (source, el) => {
      const pre = el.createEl("pre", { cls: "qnt-file-view" });
      const code = pre.createEl("code", { cls: "language-quint" });
      code.innerHTML = highlightQuintWithLineNumbers(source);
    };
    this.registerMarkdownCodeBlockProcessor("quint", renderCodeBlock);
    this.registerMarkdownCodeBlockProcessor("qnt", renderCodeBlock);
  }
};
