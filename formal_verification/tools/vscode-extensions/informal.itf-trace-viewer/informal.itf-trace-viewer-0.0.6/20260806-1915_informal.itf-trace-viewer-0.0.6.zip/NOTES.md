# Test

- Run extension in debug mode: press `F5`
- Don't forget to `npm run compile`! In case the task in `.vscode/tasks.json` does not run it.

# Publish

https://code.visualstudio.com/api/working-with-extensions/publishing-extension

You can use vsce to easily package and publish your extensions:

    ```shell
    $ cd myExtension
    $ npm run compile
    $ vsce package
    # myExtension.vsix generated
    $ vsce publish
    # <publisherID>.myExtension published to VS Code Marketplace
    ```

dsfbiakj5cpwt4muuxf5fccztymfmvdlzlgkofwkla2tvwnqj5vq