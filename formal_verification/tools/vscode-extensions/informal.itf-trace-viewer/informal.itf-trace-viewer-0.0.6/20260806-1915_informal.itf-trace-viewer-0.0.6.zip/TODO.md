## select variables on dropdown menu

when there are more than 5/6 variables, use a dropdown
- https://stackoverflow.com/questions/19206919/how-to-create-checkbox-inside-dropdown
- https://codepen.io/RobotsPlay/pres/pyNLdL
